package com.example.unsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnsecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnsecurityApplication.class, args);
	}

}
