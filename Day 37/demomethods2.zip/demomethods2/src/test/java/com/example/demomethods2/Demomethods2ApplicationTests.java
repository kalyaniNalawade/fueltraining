package com.example.demomethods2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demomethods2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
