package com.example.websecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
